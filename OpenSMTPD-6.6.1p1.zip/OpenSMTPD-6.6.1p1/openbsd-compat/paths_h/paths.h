#ifndef PATHS_H
#define PATHS_H

#ifndef _PATH_DEFPATH
#define _PATH_DEFPATH "/bin:/usr/bin"
#endif

#endif
