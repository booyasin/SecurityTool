This directory will contain example OpenSMTPD config  files that can be used as
a reference or for testing specific usecases. Tests that are run as part of
CI/CD process in docker containers will utilize these files.


* `aliases` file - default aliases map that is referenced by default OpenSMTPD config.
