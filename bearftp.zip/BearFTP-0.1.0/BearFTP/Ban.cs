using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BearFTP
{
    class Ban
    {
        public string hostname;
        public int time;
    }
}
